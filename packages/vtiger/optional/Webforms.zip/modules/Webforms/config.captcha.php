<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

/*Config file for captcha
 * enabled webforms.
 */
global $captchaConfig;
$captchaConfig=array(
        'VTIGER_RECAPTCHA_PUBLIC_KEY'=>'RECAPTCHA PUBLIC KEY FOR THIS DOMAIN',//RECAPTCHA PUBLIC KEY FOR THIS DOMAIN
'VTIGER_RECAPTCHA_PRIVATE_KEY'=>'RECAPTCHA PRIVATE KEY FOR THIS DOMAIN');//RECAPTCHA PRIVATE KEY FOR THIS DOMAIN


