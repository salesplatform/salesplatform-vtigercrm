<?php
namespace SPVoipIntegration;

class ProvidersEnum {
   
    const ZADARMA = 'zadarma';
    const GRAVITEL = 'gravitel';
    const ZEBRA = 'zebra';
    const MEGAFON = 'megafon';
    const TELPHIN = 'telphin';
    const UISCOM = 'uiscom';
    const MANGO = 'mango';
    const YANDEX = 'yandex';
    const ROSTELECOM = 'rostelecom';
    const SIPUNI = 'sipuni';
    const DOMRU = 'domru';
    const WESTCALL_SPB = 'westcall_spb';
    const MCN = 'mcn';
}
