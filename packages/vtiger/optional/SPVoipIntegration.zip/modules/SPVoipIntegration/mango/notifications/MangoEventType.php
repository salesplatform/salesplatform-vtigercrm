<?php
namespace SPVoipIntegration\mango\notifications;

class MangoEventType {
    const CALL = '/events/call';
    const RECORD = '/events/recording';
}
