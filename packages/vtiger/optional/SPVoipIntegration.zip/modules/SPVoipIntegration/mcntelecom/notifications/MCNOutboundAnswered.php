<?php
namespace SPVoipIntegration\mcntelecom\notifications;

class MCNOutboundAnswered extends MCNInboundAnswered{
    
}
