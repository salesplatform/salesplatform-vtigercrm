<?php
namespace SPVoipIntegration\sipuni\notifications;

class SipuniEventType {
    const CALL = 1;
    const HANG_UP = 2;
    const ANSWER = 3;
    const SEC_HANG_UP = 4;
}