<?php

namespace SPVoipIntegration\yandex\notifications;


class CallbackCallCompleted extends OutgoingCallCompleted{    
}
