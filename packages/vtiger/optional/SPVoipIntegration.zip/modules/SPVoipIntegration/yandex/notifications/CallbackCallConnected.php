<?php

namespace SPVoipIntegration\yandex\notifications;


class CallbackCallConnected extends OutgoingCallConnected{
    
}
