<?php

/**
 * Indicates about unsopported cml protocol version
 */
class UnsupportedProtocolVersionException extends Exception {
    
}
